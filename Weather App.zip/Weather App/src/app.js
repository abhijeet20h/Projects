const path = require('path');
const hbs =require('hbs');
const express=require('express');
const { dirname } = require('path');
const app = express();
const port = 3000;

const static_path = path.join(__dirname,  "../public");
const templete_path =path.join(__dirname, "../templetes/views");
const partial_path  =path.join(__dirname, "../templetes/partials");

app.set('view engine', 'hbs');
app.set('views', templete_path);
hbs.registerPartials(partial_path)

app.use(express.static(static_path ));

app.get('', (req, res) =>{
    res.render('index');
})

app.get('/about', (req, res) =>{
    res.render('about');
})

app.get('/weather', (req, res) =>{
    res.render('weather');
})

app.get('*', (req, res) =>{
    res.render('404error',{
        errormsg : 'OOPS ! page not found'
    });
});

app.listen( port , (req , res)=>{
    console.log(`listening to the port ${port}`)
})