import React from "react";
import "./index.css";
import Demo from "./Demo";
export default function App() {
  return (
    <div
      className="container-fluid  col-md-3 mt-5 p-5"
      style={{ border: "5px solid" }}
    >
      <Demo />
    </div>
  );
}
