import logo from './logo.svg';
import './App.css';
import Covid from './Components/Covid'

function App() {
  return (
    <div className="App">
      <Covid/>
    </div>
  );
}

export default App;
